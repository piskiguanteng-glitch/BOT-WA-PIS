const $ = (id) => document.getElementById(id);
let activeMethod = 'qr';
let pollTimer = null;
let latestState = 'disconnected';

async function api(url, options = {}) {
  const response = await fetch(url, {
    credentials: 'same-origin',
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(data.error || `Request gagal (${response.status}).`);
    error.status = response.status;
    throw error;
  }
  return data;
}

function toast(message) {
  const el = $('toast');
  el.textContent = message;
  el.classList.add('show');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => el.classList.remove('show'), 2600);
}

function setBusy(button, busy, label) {
  if (!button.dataset.originalText) button.dataset.originalText = button.innerHTML;
  button.disabled = busy;
  button.innerHTML = busy ? `<span class="spinner"></span> Memproses…` : (label || button.dataset.originalText);
}

function showLogin() {
  $('loginView').classList.remove('hidden');
  $('dashboardView').classList.add('hidden');
  $('logoutBtn').classList.add('hidden');
  if (pollTimer) clearInterval(pollTimer);
}

function showDashboard() {
  $('loginView').classList.add('hidden');
  $('dashboardView').classList.remove('hidden');
  $('logoutBtn').classList.remove('hidden');
  refreshStatus();
  if (pollTimer) clearInterval(pollTimer);
  pollTimer = setInterval(refreshStatus, 1800);
}

function setMethod(method) {
  activeMethod = method;
  const qr = method === 'qr';
  $('qrTab').classList.toggle('active', qr);
  $('codeTab').classList.toggle('active', !qr);
  $('qrTab').setAttribute('aria-selected', String(qr));
  $('codeTab').setAttribute('aria-selected', String(!qr));
  $('qrMethod').classList.toggle('hidden', !qr);
  $('codeMethod').classList.toggle('hidden', qr);
}

function renderStatus(data) {
  latestState = data.state;
  const connected = data.state === 'connected';
  const waiting = ['connecting', 'waiting_qr', 'waiting_code', 'reconnecting'].includes(data.state);
  $('statusPill').className = `status-pill ${connected ? 'on' : waiting ? 'pending' : 'off'}`;
  $('statusText').textContent = connected ? 'Terhubung' : waiting ? 'Menghubungkan' : data.state === 'error' ? 'Perlu tindakan' : 'Offline';
  $('connectionMessage').textContent = data.message || 'Status belum tersedia.';
  $('accountStatus').textContent = connected ? 'Perangkat terhubung' : waiting ? 'Sedang menghubungkan…' : 'Belum terhubung';
  $('accountPhone').textContent = connected && data.phone ? `+${data.phone}` : 'Tautkan akun WhatsApp kamu';
  $('disconnectBtn').classList.toggle('hidden', !connected && !waiting && data.state !== 'error');
  $('connectQrBtn').disabled = connected || waiting;
  $('connectCodeBtn').disabled = connected || waiting;
  $('phoneInput').disabled = connected || waiting;

  const qrVisible = !!data.qrDataUrl && !connected;
  $('qrImage').src = qrVisible ? data.qrDataUrl : '';
  $('qrImage').classList.toggle('hidden', !qrVisible);
  $('qrPlaceholder').classList.toggle('hidden', qrVisible || connected);
  $('qrConnected').classList.toggle('hidden', !connected);
  if (!qrVisible && !connected) {
    const placeholderText = data.state === 'connecting' || data.state === 'reconnecting' ? 'MENUNGGU QR DARI WHATSAPP…' : 'QR BELUM TERSEDIA';
    $('qrPlaceholder').querySelector('strong').textContent = placeholderText;
  } else {
    $('qrPlaceholder').querySelector('strong').textContent = 'QR belum tersedia';
  }

  const codeVisible = !!data.pairingCode && !connected;
  $('pairingCode').textContent = data.pairingCode || '';
  $('pairingCode').classList.toggle('hidden', !codeVisible);
  $('codePlaceholder').classList.toggle('hidden', codeVisible);
  if (!codeVisible) {
    $('codePlaceholder').textContent = data.state === 'connecting' || data.state === 'waiting_code' ? 'MEMINTA KODE TAUTAN…' : 'KODE AKAN MUNCUL DI SINI';
  }
}

async function refreshStatus() {
  try {
    const data = await api('/api/status');
    renderStatus(data);
  } catch (error) {
    if (error.status === 401) showLogin();
  }
}

$('loginForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  $('loginError').textContent = '';
  const button = $('loginForm').querySelector('button[type="submit"]');
  setBusy(button, true);
  try {
    await api('/api/login', { method: 'POST', body: JSON.stringify({ password: $('passwordInput').value }) });
    $('passwordInput').value = '';
    showDashboard();
  } catch (error) {
    $('loginError').textContent = error.message;
  } finally {
    setBusy(button, false);
  }
});

$('logoutBtn').addEventListener('click', async () => {
  try { await api('/api/logout', { method: 'POST', body: '{}' }); } catch {}
  showLogin();
});

$('qrTab').addEventListener('click', () => setMethod('qr'));
$('codeTab').addEventListener('click', () => setMethod('code'));

$('connectQrBtn').addEventListener('click', async () => {
  setBusy($('connectQrBtn'), true);
  try {
    await api('/api/connect', { method: 'POST', body: JSON.stringify({ method: 'qr' }) });
    toast('Permintaan QR dikirim.');
    await refreshStatus();
  } catch (error) { toast(error.message); }
  finally { setBusy($('connectQrBtn'), false, 'Buat QR untuk di-scan <span>→</span>'); }
});

$('connectCodeBtn').addEventListener('click', async () => {
  const phoneNumber = $('phoneInput').value.trim();
  if (!phoneNumber) return toast('Masukkan nomor WhatsApp dulu.');
  setBusy($('connectCodeBtn'), true);
  try {
    await api('/api/connect', { method: 'POST', body: JSON.stringify({ method: 'code', phoneNumber }) });
    toast('Meminta kode tautan…');
    await refreshStatus();
  } catch (error) { toast(error.message); }
  finally { setBusy($('connectCodeBtn'), false, 'Minta kode tautan <span>→</span>'); }
});

$('disconnectBtn').addEventListener('click', async () => {
  if (!window.confirm('Putuskan perangkat WhatsApp dan hapus sesi tersimpan di server?')) return;
  setBusy($('disconnectBtn'), true);
  try {
    await api('/api/disconnect', { method: 'POST', body: '{}' });
    toast('Perangkat sudah diputuskan.');
    await refreshStatus();
  } catch (error) { toast(error.message); }
  finally { setBusy($('disconnectBtn'), false, 'Putuskan perangkat'); }
});

document.querySelectorAll('[data-copy]').forEach((button) => {
  button.addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(button.dataset.copy);
      toast(`Disalin: ${button.dataset.copy}`);
    } catch { toast('Clipboard tidak tersedia di browser ini.'); }
  });
});

(async function init() {
  try {
    await api('/api/status');
    showDashboard();
  } catch (error) {
    if (error.status === 401) showLogin();
    else showLogin();
  }
})();

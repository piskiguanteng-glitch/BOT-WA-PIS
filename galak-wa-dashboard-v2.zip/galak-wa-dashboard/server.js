import 'dotenv/config';
import express from 'express';
import session from 'express-session';
import helmet from 'helmet';
import { rateLimit } from 'express-rate-limit';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  disconnectWhatsApp,
  getPublicStatus,
  startWhatsApp
} from './bot.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT || 3000);
const DASHBOARD_PASSWORD = process.env.DASHBOARD_PASSWORD || '';
const SESSION_SECRET = process.env.SESSION_SECRET || crypto.randomBytes(48).toString('hex');
const IS_PRODUCTION = process.env.NODE_ENV === 'production';

if (!DASHBOARD_PASSWORD || DASHBOARD_PASSWORD.length < 12) {
  console.error('Atur DASHBOARD_PASSWORD minimal 12 karakter sebelum menjalankan server.');
  process.exit(1);
}

if (process.env.TRUST_PROXY === '1' || IS_PRODUCTION) app.set('trust proxy', 1);
app.disable('x-powered-by');
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'"],
      imgSrc: ["'self'", 'data:'],
      connectSrc: ["'self'"],
      fontSrc: ["'self'"],
      objectSrc: ["'none'"],
      baseUri: ["'self'"],
      frameAncestors: ["'none'"]
    }
  }
}));
app.use(express.json({ limit: '20kb' }));
app.use(session({
  name: 'galak.sid',
  secret: SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: 'strict',
    secure: IS_PRODUCTION,
    maxAge: 8 * 60 * 60 * 1000
  }
}));

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 8,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: { error: 'Terlalu banyak percobaan. Coba lagi 15 menit kemudian.' }
});

function requireLogin(req, res, next) {
  if (req.session?.authenticated === true) return next();
  return res.status(401).json({ error: 'Login diperlukan.' });
}

app.get('/healthz', (_req, res) => res.json({ ok: true, app: 'GALAK BOT Dashboard' }));

app.post('/api/login', loginLimiter, (req, res) => {
  const password = typeof req.body?.password === 'string' ? req.body.password : '';
  const expected = Buffer.from(DASHBOARD_PASSWORD);
  const received = Buffer.from(password);
  const match = expected.length === received.length && crypto.timingSafeEqual(expected, received);
  if (!match) return res.status(401).json({ error: 'Password dashboard salah.' });
  req.session.regenerate((error) => {
    if (error) return res.status(500).json({ error: 'Gagal membuat sesi login.' });
    req.session.authenticated = true;
    req.session.save((saveError) => {
      if (saveError) return res.status(500).json({ error: 'Gagal menyimpan sesi login.' });
      res.json({ ok: true });
    });
  });
});

app.post('/api/logout', requireLogin, (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

app.get('/api/status', requireLogin, (_req, res) => {
  res.set('Cache-Control', 'no-store');
  res.json(getPublicStatus());
});

app.post('/api/connect', requireLogin, async (req, res) => {
  const method = req.body?.method;
  if (method !== 'qr' && method !== 'code') {
    return res.status(400).json({ error: 'Pilih metode QR atau kode.' });
  }
  let phoneNumber = null;
  if (method === 'code') {
    const raw = typeof req.body?.phoneNumber === 'string' ? req.body.phoneNumber : '';
    phoneNumber = raw.replace(/[^\d]/g, '');
    if (phoneNumber.startsWith('0')) phoneNumber = `62${phoneNumber.slice(1)}`;
    if (!/^\d{8,15}$/.test(phoneNumber)) {
      return res.status(400).json({ error: 'Masukkan nomor dengan kode negara. Contoh Indonesia: 6281234567890.' });
    }
  }
  try {
    await startWhatsApp({ method, phoneNumber });
    res.json({ ok: true, message: method === 'code' ? 'Permintaan kode tautan dimulai.' : 'Permintaan QR dimulai.' });
  } catch (error) {
    res.status(409).json({ error: error?.message || 'Bot sedang berjalan.' });
  }
});

app.post('/api/disconnect', requireLogin, async (_req, res) => {
  try {
    await disconnectWhatsApp();
    res.json({ ok: true });
  } catch (error) {
    res.status(500).json({ error: error?.message || 'Gagal memutuskan perangkat.' });
  }
});

app.use(express.static(path.join(__dirname, 'public'), { index: 'index.html', maxAge: IS_PRODUCTION ? '1h' : 0 }));

app.use((error, _req, res, _next) => {
  console.error('[HTTP ERROR]', error);
  res.status(500).json({ error: 'Terjadi kesalahan pada server.' });
});

const server = app.listen(PORT, '0.0.0.0', () => {
  console.log(`GALAK BOT Dashboard aktif di port ${PORT}`);
  console.log('Dashboard dilindungi password. Buka URL layanan untuk login.');
});

// Pulihkan sesi yang pernah ditautkan setelah server restart.
const authDir = path.resolve(process.env.AUTH_DIR || './data/auth_info_baileys');
if (fs.existsSync(path.join(authDir, 'creds.json'))) {
  startWhatsApp({ method: 'qr' }).catch((error) => console.error('[AUTO CONNECT]', error.message));
}

async function shutdown() {
  server.close(() => process.exit(0));
  try { await disconnectWhatsApp(); } catch {}
  setTimeout(() => process.exit(0), 5000).unref();
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);

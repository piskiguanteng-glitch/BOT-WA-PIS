import 'dotenv/config';
import makeWASocket, {
  DisconnectReason,
  downloadMediaMessage,
  getContentType,
  useMultiFileAuthState
} from '@whiskeysockets/baileys';
import pino from 'pino';
import sharp from 'sharp';
import QRCode from 'qrcode';
import fs from 'node:fs';
import path from 'node:path';

const logger = pino({ level: process.env.LOG_LEVEL || 'silent' });
const settings = JSON.parse(fs.readFileSync(new URL('./settings.json', import.meta.url), 'utf8'));
const PREFIX = settings.prefix || '!';
const AUTH_DIR = path.resolve(process.env.AUTH_DIR || './data/auth_info_baileys');

let socket = null;
let starting = false;
let reconnectTimer = null;
let shouldReconnect = false;
let pairingNumber = null;
let pairingRequested = false;
let status = {
  state: 'disconnected',
  message: 'Belum terhubung ke WhatsApp.',
  qrDataUrl: null,
  pairingCode: null,
  connectedAt: null,
  phone: null
};
let onStatus = () => {};

function publish(patch) {
  status = { ...status, ...patch };
  onStatus({ ...status });
}

function unwrapMessage(message) {
  let current = message;
  while (current?.ephemeralMessage?.message || current?.viewOnceMessage?.message || current?.viewOnceMessageV2?.message) {
    current = current.ephemeralMessage?.message || current.viewOnceMessage?.message || current.viewOnceMessageV2?.message;
  }
  return current;
}

function getText(message) {
  const content = unwrapMessage(message);
  return content?.conversation
    || content?.extendedTextMessage?.text
    || content?.imageMessage?.caption
    || content?.videoMessage?.caption
    || content?.documentMessage?.caption
    || '';
}

function getContextInfo(message) {
  const content = unwrapMessage(message);
  const type = getContentType(content);
  return content?.[type]?.contextInfo || content?.extendedTextMessage?.contextInfo;
}

function escapeXml(value) {
  return value.replace(/[<>&"']/g, (char) => ({
    '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;', "'": '&apos;'
  })[char]);
}

function wrapText(text, maxChars, maxLines = 8) {
  const words = text.trim().split(/\s+/);
  const lines = [];
  let line = '';
  for (const word of words) {
    const pieces = word.length > maxChars ? word.match(new RegExp(`.{1,${maxChars}}`, 'g')) : [word];
    for (const piece of pieces) {
      const candidate = line ? `${line} ${piece}` : piece;
      if (candidate.length > maxChars && line) {
        lines.push(line);
        line = piece;
      } else line = candidate;
      if (lines.length >= maxLines) break;
    }
    if (lines.length >= maxLines) break;
  }
  if (line && lines.length < maxLines) lines.push(line);
  if (lines.length === maxLines && words.join(' ').length > lines.join(' ').length) {
    lines[maxLines - 1] = `${lines[maxLines - 1].slice(0, Math.max(1, maxChars - 1))}…`;
  }
  return lines.length ? lines : ['brat'];
}

async function makeBratImage(input) {
  const text = input.trim().slice(0, 220);
  if (!text) throw new Error('Tulis teks setelah perintah brat.');
  const maxChars = text.length > 130 ? 15 : text.length > 75 ? 18 : 22;
  const fontSize = text.length > 130 ? 30 : text.length > 75 ? 37 : text.length > 38 ? 44 : 54;
  const lines = wrapText(text, maxChars, 7);
  const lineHeight = fontSize * 1.12;
  const firstY = 256 - ((lines.length - 1) * lineHeight) / 2 + fontSize * 0.35;
  const tspans = lines.map((line, index) =>
    `<tspan x="256" y="${(firstY + index * lineHeight).toFixed(1)}">${escapeXml(line)}</tspan>`
  ).join('');
  const svg = `<svg width="512" height="512" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><rect width="512" height="512" fill="#8ACE00"/><text text-anchor="middle" dominant-baseline="middle" fill="#050505" font-family="Arial, Helvetica, sans-serif" font-size="${fontSize}" font-weight="900" letter-spacing="-2">${tspans}</text></svg>`;
  return sharp(Buffer.from(svg)).png().toBuffer();
}

function getQuotedMessage(message) {
  const context = getContextInfo(message.message);
  if (!context?.quotedMessage) return null;
  return {
    key: {
      remoteJid: message.key.remoteJid,
      id: context.stanzaId || `quoted-${Date.now()}`,
      participant: context.participant,
      fromMe: false
    },
    message: context.quotedMessage
  };
}

async function downloadImageOrSticker(sock, message) {
  const quoted = getQuotedMessage(message);
  const source = quoted || message;
  const content = unwrapMessage(source.message);
  const type = getContentType(content);
  if (type !== 'imageMessage' && type !== 'stickerMessage') {
    throw new Error(`Kirim foto dengan caption ${PREFIX}sticker atau balas foto/sticker dengan ${PREFIX}sticker.`);
  }
  return downloadMediaMessage(source, 'buffer', {}, {
    logger,
    reuploadRequest: sock.updateMediaMessage
  });
}

const MENU = `╭━━━「 ${settings.botName || 'GALAK BOT'} 」━━━\n┃\n┃  *STICKER & BRAT*\n┃  ${PREFIX}sticker       - Foto jadi sticker\n┃  ${PREFIX}toimg         - Sticker jadi gambar\n┃  ${PREFIX}brat teks     - Buat gambar brat\n┃  ${PREFIX}bratsticker teks - Brat jadi sticker\n┃\n┃  *TOOLS*\n┃  ${PREFIX}qr teks        - Buat QR code\n┃  ${PREFIX}reverse teks   - Balik teks\n┃  ${PREFIX}upper teks     - Huruf kapital\n┃  ${PREFIX}lower teks     - Huruf kecil\n┃  ${PREFIX}ping           - Cek bot aktif\n┃  ${PREFIX}menu            - Tampilkan menu\n┃\n╰━━━━━━━━━━━━━━━━━━━━━━\nBisa dipakai di chat pribadi dan grup.\nContoh: ${PREFIX}brat halo dunia`;

async function handleCommand(sock, message) {
  const jid = message.key.remoteJid;
  if (!jid || jid === 'status@broadcast' || jid.endsWith('@newsletter')) return;
  const body = getText(message.message).trim();
  if (!body.startsWith(PREFIX)) return;
  const withoutPrefix = body.slice(PREFIX.length).trim();
  const firstSpace = withoutPrefix.indexOf(' ');
  const command = (firstSpace === -1 ? withoutPrefix : withoutPrefix.slice(0, firstSpace)).toLowerCase();
  const args = firstSpace === -1 ? '' : withoutPrefix.slice(firstSpace + 1).trim();
  const reply = (text) => sock.sendMessage(jid, { text }, { quoted: message });

  try {
    switch (command) {
      case 'menu': case 'help': await reply(MENU); break;
      case 'ping': await reply('Pong! GALAK BOT aktif.'); break;
      case 'brat': {
        if (!args) return reply(`Tulis teksnya.\nContoh: ${PREFIX}brat halo dunia`);
        const image = await makeBratImage(args);
        await sock.sendMessage(jid, { image, caption: `Brat: ${args.slice(0, 100)}` }, { quoted: message });
        break;
      }
      case 'bratsticker': {
        if (!args) return reply(`Tulis teksnya.\nContoh: ${PREFIX}bratsticker halo dunia`);
        const image = await makeBratImage(args);
        const sticker = await sharp(image).resize(512, 512, { fit: 'contain' }).webp({ quality: 82 }).toBuffer();
        await sock.sendMessage(jid, { sticker, packname: settings.stickerPack, author: settings.stickerAuthor }, { quoted: message });
        break;
      }
      case 'sticker': case 's': {
        const media = await downloadImageOrSticker(sock, message);
        const sticker = await sharp(media).rotate().resize(512, 512, { fit: 'inside', withoutEnlargement: true }).webp({ quality: 82 }).toBuffer();
        await sock.sendMessage(jid, { sticker, packname: settings.stickerPack, author: settings.stickerAuthor }, { quoted: message });
        break;
      }
      case 'toimg': case 'toimage': {
        const media = await downloadImageOrSticker(sock, message);
        const png = await sharp(media).png().toBuffer();
        await sock.sendMessage(jid, { image: png, caption: 'Sticker berhasil diubah menjadi gambar.' }, { quoted: message });
        break;
      }
      case 'qr': {
        if (!args) return reply(`Tulis teks atau link.\nContoh: ${PREFIX}qr https://example.com`);
        const png = await QRCode.toBuffer(args.slice(0, 1500), { type: 'png', width: 640, margin: 2, errorCorrectionLevel: 'M' });
        await sock.sendMessage(jid, { image: png, caption: 'QR code berhasil dibuat.' }, { quoted: message });
        break;
      }
      case 'reverse':
        if (!args) return reply(`Contoh: ${PREFIX}reverse halo dunia`);
        await reply(Array.from(args).reverse().join('')); break;
      case 'upper':
        if (!args) return reply(`Contoh: ${PREFIX}upper halo dunia`);
        await reply(args.toLocaleUpperCase('id-ID')); break;
      case 'lower':
        if (!args) return reply(`Contoh: ${PREFIX}lower HALO DUNIA`);
        await reply(args.toLocaleLowerCase('id-ID')); break;
      default: await reply(`Perintah tidak ditemukan. Ketik ${PREFIX}menu untuk melihat daftar perintah.`);
    }
  } catch (error) {
    console.error(`[COMMAND ERROR] ${command}:`, error?.message || error);
    try { await reply(`Gagal menjalankan perintah: ${error?.message || 'terjadi kesalahan.'}`); } catch {}
  }
}

export function getBotStatus() {
  return { ...status };
}

export function setStatusListener(listener) {
  onStatus = typeof listener === 'function' ? listener : () => {};
}

export async function startWhatsApp({ method = 'qr', phoneNumber = null } = {}) {
  if (starting || ['connecting', 'waiting_qr', 'waiting_code', 'connected', 'reconnecting'].includes(status.state)) {
    throw new Error('Bot sedang berjalan atau sedang menghubungkan.');
  }
  if (reconnectTimer) clearTimeout(reconnectTimer);
  reconnectTimer = null;
  starting = true;
  shouldReconnect = true;
  pairingNumber = phoneNumber;
  pairingRequested = false;
  publish({ state: 'connecting', message: 'Menghubungkan ke WhatsApp…', qrDataUrl: null, pairingCode: null, connectedAt: null, phone: null });
  await connectSocket();
}

async function connectSocket() {
  if (starting && socket) return;
  starting = true;
  try {
    const { state, saveCreds } = await useMultiFileAuthState(AUTH_DIR);
    const sock = makeWASocket({
      auth: state,
      logger,
      printQRInTerminal: false,
      markOnlineOnConnect: false,
      browser: ['GALAK BOT', 'Chrome', '2.0.0'],
      syncFullHistory: false
    });
    socket = sock;
    sock.ev.on('creds.update', saveCreds);

    sock.ev.on('connection.update', async ({ connection, lastDisconnect, qr }) => {
      if (qr) {
        if (pairingNumber && !state.creds.registered && !pairingRequested) {
          pairingRequested = true;
          publish({ state: 'waiting_code', message: 'Kode tautan sedang diminta dari WhatsApp…', qrDataUrl: null, pairingCode: null });
          try {
            const code = await sock.requestPairingCode(pairingNumber);
            publish({ state: 'waiting_code', message: 'Masukkan kode ini di WhatsApp → Perangkat tertaut → Tautkan perangkat → Tautkan dengan nomor telepon.', pairingCode: code, qrDataUrl: null });
          } catch (error) {
            pairingRequested = false;
            publish({ state: 'error', message: `Gagal meminta kode: ${error?.message || 'kesalahan WhatsApp'}`, pairingCode: null });
          }
        } else if (!state.creds.registered && !pairingNumber) {
          try {
            const dataUrl = await QRCode.toDataURL(qr, { width: 300, margin: 2 });
            publish({ state: 'waiting_qr', message: 'Pindai QR dari menu Perangkat Tertaut di WhatsApp.', qrDataUrl: dataUrl, pairingCode: null });
          } catch (error) {
            publish({ state: 'error', message: `QR gagal dibuat: ${error.message}` });
          }
        }
      }

      if (connection === 'connecting') {
        publish({ state: 'connecting', message: 'Membuka koneksi WhatsApp…' });
      }
      if (connection === 'open') {
        const phone = state.creds.me?.id?.split(':')[0]?.split('@')[0] || null;
        pairingNumber = null;
        publish({ state: 'connected', message: 'WhatsApp berhasil terhubung. Bot siap menerima perintah.', qrDataUrl: null, pairingCode: null, connectedAt: new Date().toISOString(), phone });
      }
      if (connection === 'close') {
        const code = lastDisconnect?.error?.output?.statusCode;
        const loggedOut = code === DisconnectReason.loggedOut;
        socket = null;
        starting = false;
        if (loggedOut) {
          shouldReconnect = false;
          await fs.promises.rm(AUTH_DIR, { recursive: true, force: true }).catch(() => {});
          publish({ state: 'disconnected', message: 'Sesi WhatsApp sudah keluar. Hubungkan ulang dengan QR atau kode.', qrDataUrl: null, pairingCode: null, phone: null });
        } else if (shouldReconnect) {
          publish({ state: 'reconnecting', message: 'Koneksi terputus. Mencoba menyambungkan kembali…', qrDataUrl: null, pairingCode: null });
          if (reconnectTimer) clearTimeout(reconnectTimer);
          reconnectTimer = setTimeout(() => {
            reconnectTimer = null;
            connectSocket().catch((error) => publish({ state: 'error', message: `Gagal menyambung ulang: ${error.message}` }));
          }, code === DisconnectReason.restartRequired ? 500 : 2500);
        } else {
          publish({ state: 'disconnected', message: 'Bot terputus dari WhatsApp.', qrDataUrl: null, pairingCode: null });
        }
      }
    });

    sock.ev.on('messages.upsert', async ({ messages, type }) => {
      if (type !== 'notify') return;
      for (const message of messages) {
        if (message.message) await handleCommand(sock, message);
      }
    });
    starting = false;
  } catch (error) {
    starting = false;
    socket = null;
    publish({ state: 'error', message: `Tidak bisa memulai bot: ${error?.message || 'kesalahan tidak diketahui'}` });
    throw error;
  }
}

export async function disconnectWhatsApp() {
  shouldReconnect = false;
  if (reconnectTimer) clearTimeout(reconnectTimer);
  reconnectTimer = null;
  const current = socket;
  socket = null;
  starting = false;
  pairingNumber = null;
  pairingRequested = false;
  if (current) {
    try { await current.logout(); } catch {}
  }
  await fs.promises.rm(AUTH_DIR, { recursive: true, force: true });
  publish({ state: 'disconnected', message: 'Perangkat WhatsApp sudah dilepas.', qrDataUrl: null, pairingCode: null, connectedAt: null, phone: null });
}

export function getPublicStatus() {
  const { state, message, qrDataUrl, pairingCode, connectedAt, phone } = status;
  return { state, message, qrDataUrl, pairingCode, connectedAt, phone, botName: settings.botName || 'GALAK BOT' };
}
